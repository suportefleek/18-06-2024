window.addEventListener("DOMContentLoaded", () => {
    const devOrDesigner = new DevOrDesigner("#occupation")
})

class DevOrDesigner {
    constructor(buttonEl) {
        this.button = document.querySelector(buttonEl)
        this.button?.addEventListener("click", this.occupationToggle.bind(this))
    }
    _occupation = "developer"
    get occupation() {
        return this._occupation
    }
    set occupation(value) {
        this._occupation = value
        this.button?.setAttribute("aria-labelledby", this._occupation)
    }
    occupationToggle() {
        this.occupation = this.occupation === "developer" ? "designer" : "developer"
    }
}
